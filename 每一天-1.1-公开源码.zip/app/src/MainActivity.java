package cn.meiyitian.shelf;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.ClipData;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.AtomicFile;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.zip.ZipFile;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private AtomicFile journal;
    private File photos;
    private ValueCallback<Uri[]> iconChooser;
    private final Object storageLock = new Object();
    private volatile boolean backupBusy;
    private static final int EXPORT_BACKUP = 24;
    private static final int IMPORT_BACKUP = 25;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(45, 62, 52));
        getWindow().setNavigationBarColor(Color.rgb(45, 62, 52));
        journal = new AtomicFile(new File(getFilesDir(), "journal.json"));
        photos = new File(getFilesDir(), "photos");
        photos.mkdirs();
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(242, 232, 212));
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> result,
                                                        FileChooserParams parameters) {
                if (iconChooser != null) iconChooser.onReceiveValue(null);
                iconChooser = result;
                try { startActivityForResult(imagePicker(), 23); }
                catch (Exception e) {
                    iconChooser = null;
                    result.onReceiveValue(null);
                }
                return true;
            }
        });
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.addJavascriptInterface(new Storage(), "Device");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class Storage {
        @JavascriptInterface public String read() {
            try { return new String(journal.readFully(), StandardCharsets.UTF_8); }
            catch (java.io.FileNotFoundException e) {
                return journal.getBaseFile().exists() ? "!" : "";
            } catch (Exception e) { return "!"; }
        }

        @JavascriptInterface public boolean save(String value) {
            synchronized (storageLock) {
                if (backupBusy) return false;
                try {
                    writeJournal(value.getBytes(StandardCharsets.UTF_8));
                    return true;
                } catch (IOException e) { return false; }
            }
        }

        @JavascriptInterface public void exportBackup() {
            runOnUiThread(() -> startBackupPicker(true));
        }

        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> startBackupPicker(false));
        }

        @JavascriptInterface public void pick() {
            runOnUiThread(() -> {
                try { startActivityForResult(imagePicker(), 21); }
                catch (Exception e) { callback("photoFailed()"); }
            });
        }

        @JavascriptInterface public void camera() {
            runOnUiThread(() -> {
                File pending = new File(getCacheDir(), "camera-pending.jpg");
                pending.delete();
                Uri output = CameraOutput.uri(MainActivity.this);
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, output);
                intent.setClipData(ClipData.newRawUri("photo", output));
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try {
                    try (FileOutputStream outputFile = new FileOutputStream(pending)) {
                        outputFile.flush();
                    }
                    startActivityForResult(intent, 22);
                } catch (Exception e) {
                    pending.delete();
                    callback("photoFailed()");
                }
            });
        }

        @JavascriptInterface public String path(String name) {
            return validName(name) ? Uri.fromFile(new File(photos, name)).toString() : "";
        }

        @JavascriptInterface public void remove(String name) {
            synchronized (storageLock) {
                if (validName(name)) new File(photos, name).delete();
            }
        }
    }

    private void writeJournal(byte[] data) throws IOException {
        FileOutputStream stream = journal.startWrite();
        try {
            stream.write(data);
            stream.getFD().sync();
        } catch (IOException e) {
            journal.failWrite(stream);
            throw e;
        }
        journal.finishWrite(stream);
        if (!Arrays.equals(data, journal.readFully())) throw new IOException("保存校验失败");
    }

    private void startBackupPicker(boolean export) {
        if (backupBusy) return;
        Intent intent = new Intent(export ? Intent.ACTION_CREATE_DOCUMENT : Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(export ? "application/zip" : "*/*");
        if (export) {
            String date = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ROOT)
                .format(new java.util.Date());
            intent.putExtra(Intent.EXTRA_TITLE, "每一天备份-" + date + ".zip");
        }
        try { startActivityForResult(intent, export ? EXPORT_BACKUP : IMPORT_BACKUP); }
        catch (Exception e) { showBackupMessage("无法打开文件选择器", "请确认手机有可用的文件管理应用。"); }
    }

    private ProgressDialog backupProgress(String message) {
        backupBusy = true;
        ProgressDialog progress = new ProgressDialog(this);
        progress.setMessage(message);
        progress.setCancelable(false);
        progress.show();
        return progress;
    }

    private void showBackupMessage(String title, String message) {
        if (!isFinishing()) new AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("确定", null).show();
    }

    private void exportBackup(Uri location) {
        ProgressDialog progress = backupProgress("正在导出备份…");
        new Thread(() -> {
            String failure = null;
            File staged = null;
            try {
                staged = File.createTempFile("backup-export-", ".zip", getCacheDir());
                synchronized (storageLock) {
                    try (OutputStream out = new FileOutputStream(staged)) {
                        BackupArchive.exportTo(out, journal.readFully(), photos);
                    }
                }
                try (InputStream input = new FileInputStream(staged);
                     OutputStream out = getContentResolver().openOutputStream(location, "wt")) {
                    if (out == null) throw new IOException("无法写入所选位置");
                    BackupArchive.copy(input, out, Long.MAX_VALUE);
                }
            } catch (Exception e) { failure = backupError(e); }
            finally { if (staged != null) staged.delete(); }
            String error = failure;
            runOnUiThread(() -> {
                backupBusy = false;
                progress.dismiss();
                showBackupMessage(error == null ? "备份已导出" : "导出失败",
                    error == null ? "请妥善保存 ZIP，文件包含完整记录和配图。" : error);
            });
        }).start();
    }

    private void inspectBackup(Uri location) {
        ProgressDialog progress = backupProgress("正在检查备份…");
        new Thread(() -> {
            File staged = null;
            try {
                staged = File.createTempFile("backup-import-", ".zip", getCacheDir());
                try (InputStream input = getContentResolver().openInputStream(location);
                     OutputStream out = new FileOutputStream(staged)) {
                    if (input == null) throw new IOException("无法打开所选文件");
                    BackupArchive.copy(input, out, 1024L * 1024 * 1024 + 16L * 1024 * 1024);
                }
                BackupArchive archive;
                try (ZipFile zip = new ZipFile(staged)) { archive = BackupArchive.inspect(zip); }
                File ready = staged;
                runOnUiThread(() -> {
                    progress.dismiss();
                    if (isFinishing()) { ready.delete(); backupBusy = false; return; }
                    new AlertDialog.Builder(this).setTitle("恢复这份备份？")
                        .setMessage(archive.books + " 本书、" + archive.records + " 条记录、"
                            + archive.photos.size() + " 张照片。恢复会替换这台手机上的现有记录和主题。")
                        .setNegativeButton("取消", (dialog, which) -> { ready.delete(); backupBusy = false; })
                        .setOnCancelListener(dialog -> { ready.delete(); backupBusy = false; })
                        .setPositiveButton("替换并恢复", (dialog, which) -> restoreBackup(ready, archive))
                        .show();
                });
            } catch (Exception e) {
                if (staged != null) staged.delete();
                String error = backupError(e);
                runOnUiThread(() -> {
                    backupBusy = false;
                    progress.dismiss();
                    showBackupMessage("无法读取备份", error);
                });
            }
        }).start();
    }

    private void restoreBackup(File staged, BackupArchive archive) {
        ProgressDialog progress = backupProgress("正在恢复记录和照片…");
        new Thread(() -> {
            String failure = null;
            try {
                synchronized (storageLock) {
                    File[] previous = photos.listFiles();
                    Map<String, File> images;
                    try (ZipFile zip = new ZipFile(staged)) { images = archive.restorePhotos(zip, photos); }
                    byte[] restored = archive.remap(images);
                    writeJournal(restored);
                    if (previous != null) for (File old : previous) {
                        if (BackupArchive.validPhoto(old.getName())) old.delete();
                    }
                }
            } catch (Exception e) { failure = backupError(e); }
            finally { staged.delete(); }
            String error = failure;
            runOnUiThread(() -> {
                progress.dismiss();
                if (error == null) web.reload();
                else showBackupMessage("恢复失败", error);
                backupBusy = false;
                if (error == null) showBackupMessage("恢复完成", "书架和主题已重新载入。");
            });
        }).start();
    }

    private String backupError(Exception error) {
        if (error instanceof IOException && error.getMessage() != null
                && error.getMessage().matches("[\u4e00-\u9fff0-9 GB]+")) return error.getMessage();
        return "请确认文件是由《每一天》导出的完整备份，并检查可用空间。";
    }

    private Intent imagePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        return intent;
    }

    private boolean validName(String name) {
        return BackupArchive.validPhoto(name);
    }

    private void callback(String javascript) {
        web.evaluateJavascript(javascript, null);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == EXPORT_BACKUP || request == IMPORT_BACKUP) {
            if (result == RESULT_OK && data != null && data.getData() != null) {
                if (request == EXPORT_BACKUP) exportBackup(data.getData());
                else inspectBackup(data.getData());
            }
            return;
        }
        if (request == 23) {
            ValueCallback<Uri[]> chooser = iconChooser;
            iconChooser = null;
            if (chooser != null) chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            return;
        }
        if (request == 22) {
            File pending = new File(getCacheDir(), "camera-pending.jpg");
            revokeUriPermission(CameraOutput.uri(this),
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (result != RESULT_OK) {
                pending.delete();
                callback("photoCancelled()");
            } else {
                new Thread(() -> {
                    try {
                        ExifInterface metadata = new ExifInterface(pending.getAbsolutePath());
                        int orientation = metadata.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL);
                        savePhoto(orient(decodePhoto(() -> new FileInputStream(pending)), orientation));
                    }
                    catch (Exception e) { runOnUiThread(() -> callback("photoFailed()")); }
                    finally { pending.delete(); }
                }).start();
            }
            return;
        }
        if (request != 21) return;
        if (result != RESULT_OK || data == null || data.getData() == null) {
            callback("photoCancelled()");
            return;
        }
        Uri uri = data.getData();
        new Thread(() -> {
            try {
                savePhoto(decodePhoto(() -> getContentResolver().openInputStream(uri)));
            } catch (Exception e) {
                runOnUiThread(() -> callback("photoFailed()"));
            }
        }).start();
    }

    private interface PhotoInput {
        InputStream open() throws java.io.IOException;
    }

    private Bitmap decodePhoto(PhotoInput source) throws java.io.IOException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try (InputStream input = source.open()) {
            BitmapFactory.decodeStream(input, null, options);
        }
        options.inJustDecodeBounds = false;
        options.inSampleSize = 1;
        while (Math.max(options.outWidth, options.outHeight) / options.inSampleSize > 1920) {
            options.inSampleSize *= 2;
        }
        try (InputStream input = source.open()) {
            Bitmap bitmap = BitmapFactory.decodeStream(input, null, options);
            if (bitmap == null) throw new java.io.IOException("Invalid image");
            return bitmap;
        }
    }

    private Bitmap orient(Bitmap bitmap, int orientation) {
        Matrix matrix = new Matrix();
        switch (orientation) {
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: matrix.setScale(-1, 1); break;
            case ExifInterface.ORIENTATION_ROTATE_180: matrix.setRotate(180); break;
            case ExifInterface.ORIENTATION_FLIP_VERTICAL: matrix.setScale(1, -1); break;
            case ExifInterface.ORIENTATION_TRANSPOSE:
                matrix.setRotate(90);
                matrix.postScale(-1, 1);
                break;
            case ExifInterface.ORIENTATION_ROTATE_90: matrix.setRotate(90); break;
            case ExifInterface.ORIENTATION_TRANSVERSE:
                matrix.setRotate(270);
                matrix.postScale(-1, 1);
                break;
            case ExifInterface.ORIENTATION_ROTATE_270: matrix.setRotate(270); break;
            default: return bitmap;
        }
        Bitmap oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),
            bitmap.getHeight(), matrix, true);
        if (oriented != bitmap) bitmap.recycle();
        return oriented;
    }

    public static class CameraOutput extends ContentProvider {
        static Uri uri(android.content.Context context) {
            return Uri.parse("content://" + context.getPackageName() + ".camera/photo");
        }

        @Override public boolean onCreate() { return true; }

        @Override public ParcelFileDescriptor openFile(Uri uri, String mode)
                throws FileNotFoundException {
            if (!uri.equals(uri(getContext()))) throw new FileNotFoundException();
            File file = new File(getContext().getCacheDir(), "camera-pending.jpg");
            return ParcelFileDescriptor.open(file, ParcelFileDescriptor.parseMode(mode));
        }

        @Override public Cursor query(Uri uri, String[] projection, String selection,
                                      String[] arguments, String sortOrder) {
            if (!uri.equals(uri(getContext()))) return null;
            String[] columns = projection != null ? projection
                : new String[]{"_display_name", "_size"};
            MatrixCursor cursor = new MatrixCursor(columns);
            MatrixCursor.RowBuilder row = cursor.newRow();
            for (String column : columns) {
                if ("_display_name".equals(column)) row.add("photo.jpg");
                else if ("_size".equals(column)) row.add(new File(getContext().getCacheDir(),
                    "camera-pending.jpg").length());
                else row.add(null);
            }
            return cursor;
        }

        @Override public String getType(Uri uri) { return "image/jpeg"; }
        @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
        @Override public int update(Uri uri, ContentValues values, String selection, String[] args) {
            throw new UnsupportedOperationException();
        }
        @Override public int delete(Uri uri, String selection, String[] args) {
            throw new UnsupportedOperationException();
        }
    }

    private void savePhoto(Bitmap bitmap) {
        String name = UUID.randomUUID() + ".jpg";
        File file = new File(photos, name);
        try {
            try (FileOutputStream output = new FileOutputStream(file)) {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 78, output)) throw new java.io.IOException();
            }
            runOnUiThread(() -> callback("photoReady(" + JSONObject.quote(name) + ")"));
        } catch (Exception e) {
            file.delete();
            runOnUiThread(() -> callback("photoFailed()"));
        } finally {
            bitmap.recycle();
        }
    }

    @Override public void onBackPressed() {
        callback("goBack()");
    }
}

