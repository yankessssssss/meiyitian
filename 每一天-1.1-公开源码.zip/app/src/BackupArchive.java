package cn.meiyitian.shelf;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class BackupArchive {
    private static final String HEADER = "manifest.json";
    private static final String JOURNAL = "journal.json";
    private static final int MAX_JOURNAL = 32 * 1024 * 1024;
    private static final int MAX_PHOTO = 8 * 1024 * 1024;
    private static final long MAX_ARCHIVE = 1024L * 1024 * 1024;
    private static final String TYPE = "cn.meiyitian.shelf.backup";

    final JSONObject journal;
    final Set<String> photos = new LinkedHashSet<>();
    final int books;
    int records;

    private BackupArchive(JSONObject journal) throws JSONException, IOException {
        this.journal = journal;
        JSONArray list = journal.getJSONArray("books");
        books = list.length();
        Set<String> bookIds = new LinkedHashSet<>();
        for (int i = 0; i < books; i++) {
            JSONObject book = list.getJSONObject(i);
            String id = identifier(book);
            require(bookIds.add(id), "书本编号重复");
            book.getString("name");
            String type = book.getString("type");
            require(type.matches("money|timer|diary"), "书本类型无效");
            int cover = book.getInt("cover");
            require(cover >= 0 && cover <= 5, "封面无效");
            JSONArray entries = book.getJSONArray("entries");
            Set<String> entryIds = new LinkedHashSet<>();
            records += entries.length();
            for (int j = 0; j < entries.length(); j++) {
                JSONObject entry = entries.getJSONObject(j);
                require(entryIds.add(identifier(entry)), "记录编号重复");
                require(entry.getString("day").matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"), "记录日期无效");
                require(Math.abs(entry.getLong("time")) < 8640000000000000L, "记录时间无效");
                entry.getString("text");
                if ("money".equals(type)) require(entry.getLong("cents") > 0, "金额无效");
                if ("timer".equals(type)) require(entry.getLong("ms") >= 0, "计时时长无效");
                JSONArray images = entry.optJSONArray("photos");
                if (images == null) continue;
                for (int k = 0; k < images.length(); k++) {
                    String name = images.getString(k);
                    require(validPhoto(name), "照片文件名无效");
                    photos.add(name);
                }
            }
            JSONArray tasks = book.optJSONArray("tasks");
            if (tasks != null) for (int j = 0; j < tasks.length(); j++) {
                JSONObject task = tasks.getJSONObject(j);
                identifier(task);
                task.getString("name");
                int minutes = task.getInt("minutes");
                require(minutes >= 0 && minutes <= 720, "任务时间无效");
            }
        }
        JSONObject timer = journal.optJSONObject("timer");
        require(journal.isNull("timer") || timer != null, "计时状态无效");
        if (timer != null) {
            require(bookIds.contains(timer.getString("book")), "计时所属书本不存在");
            timer.getString("text");
            timer.getLong("start");
            require(timer.optLong("limit", 0) >= 0 && timer.optLong("limit", 0) <= 43200000,
                "计时目标无效");
            JSONArray segments = timer.optJSONArray("segments");
            if (segments != null) for (int i = 0; i < segments.length(); i++) {
                JSONArray segment = segments.getJSONArray(i);
                require(segment.getLong(1) >= segment.getLong(0), "计时区间无效");
            }
        }
        JSONObject theme = journal.optJSONObject("theme");
        if (theme != null) {
            require(theme.optString("ink", "#342b22").matches("#[0-9a-fA-F]{6}"), "文字颜色无效");
            require(theme.optString("background", "room").matches("room|autumn|mist|cream|none|custom"), "背景无效");
            require(theme.optString("font", "serif").matches("serif|sans|kai"), "字体无效");
            require(theme.optString("surface", "paper").matches("paper|linen|glass"), "界面样式无效");
            require(theme.optString("weather", "sun").matches("sun|rain|cloud|storm|off"), "天气无效");
            String image = theme.optString("image");
            if (!image.isEmpty()) require(jpegData(image), "自定义背景无效");
            if ("custom".equals(theme.optString("background"))) require(!image.isEmpty(), "缺少自定义背景");
        }
        JSONObject categories = journal.optJSONObject("categories");
        if (categories != null) for (String direction : new String[]{"in", "out"}) {
            if (!categories.has(direction)) continue;
            JSONArray items = categories.getJSONArray(direction);
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.getJSONObject(i);
                item.getString("name");
                String icon = item.getString("icon");
                require(icon.length() <= 16 || jpegData(icon), "分类图标无效");
            }
        }
    }

    private static boolean jpegData(String value) {
        return value.startsWith("data:image/jpeg;base64,")
            && value.indexOf('"') < 0 && value.indexOf(')') < 0 && value.indexOf('<') < 0;
    }

    private static String identifier(JSONObject object) throws JSONException, IOException {
        String id = object.getString("id");
        require(id.matches("[a-zA-Z0-9_-]{1,80}"), "记录编号无效");
        return id;
    }

    static boolean validPhoto(String name) {
        return name.matches("[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}\\.jpg");
    }

    static void exportTo(OutputStream destination, byte[] data, File directory)
            throws IOException, JSONException {
        require(data.length <= MAX_JOURNAL, "记录文件过大");
        BackupArchive archive = new BackupArchive(new JSONObject(new String(data, StandardCharsets.UTF_8)));
        JSONObject manifest = new JSONObject().put("format", TYPE).put("version", 1);
        try (ZipOutputStream zip = new ZipOutputStream(destination)) {
            add(zip, HEADER, manifest.toString().getBytes(StandardCharsets.UTF_8));
            add(zip, JOURNAL, data);
            long total = data.length;
            for (String name : archive.photos) {
                File source = new File(directory, name);
                require(source.isFile() && source.length() <= MAX_PHOTO, "照片缺失或文件过大");
                total += source.length();
                require(total <= MAX_ARCHIVE, "备份大于 1 GB");
                zip.putNextEntry(new ZipEntry("photos/" + name));
                try (InputStream input = new FileInputStream(source)) { copy(input, zip, MAX_PHOTO); }
                zip.closeEntry();
            }
        }
    }

    static BackupArchive inspect(ZipFile zip) throws IOException, JSONException {
        Map<String, ZipEntry> entries = new HashMap<>();
        long total = 0;
        for (Enumeration<? extends ZipEntry> it = zip.entries(); it.hasMoreElements();) {
            ZipEntry entry = it.nextElement();
            String name = entry.getName();
            boolean photo = name.startsWith("photos/") && validPhoto(name.substring(7));
            require(HEADER.equals(name) || JOURNAL.equals(name) || photo, "备份包含无法识别的文件");
            require(!entry.isDirectory() && entries.put(name, entry) == null, "备份文件重复");
            long limit = photo ? MAX_PHOTO : HEADER.equals(name) ? 1024 : MAX_JOURNAL;
            long size = entry.getSize();
            require(size >= 0 && size <= limit, "备份内文件过大");
            total += size;
            require(total <= MAX_ARCHIVE, "备份大于 1 GB");
        }
        JSONObject header = new JSONObject(readText(zip, entries.get(HEADER), 1024));
        require(TYPE.equals(header.optString("format")) && header.optInt("version") == 1, "备份格式或版本不支持");
        BackupArchive archive = new BackupArchive(new JSONObject(readText(zip, entries.get(JOURNAL), MAX_JOURNAL)));
        require(entries.size() == archive.photos.size() + 2, "照片清单不匹配");
        for (String name : archive.photos) require(entries.containsKey("photos/" + name), "备份缺少照片");
        return archive;
    }

    Map<String, File> restorePhotos(ZipFile zip, File directory) throws IOException {
        Map<String, File> images = new LinkedHashMap<>();
        try {
            for (String name : photos) {
                File file = new File(directory, UUID.randomUUID() + ".jpg");
                images.put(name, file);
                ZipEntry entry = zip.getEntry("photos/" + name);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    long size = copyEntry(zip, entry, out, MAX_PHOTO);
                    require(size > 3, "照片损坏");
                    out.getFD().sync();
                }
            }
            return images;
        } catch (IOException error) {
            for (File image : images.values()) image.delete();
            throw error;
        }
    }

    byte[] remap(Map<String, File> images) throws JSONException {
        JSONArray list = journal.getJSONArray("books");
        for (int i = 0; i < list.length(); i++) {
            JSONArray entries = list.getJSONObject(i).getJSONArray("entries");
            for (int j = 0; j < entries.length(); j++) {
                JSONArray names = entries.getJSONObject(j).optJSONArray("photos");
                if (names == null) continue;
                for (int k = 0; k < names.length(); k++) names.put(k, images.get(names.getString(k)).getName());
            }
        }
        return journal.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static String readText(ZipFile zip, ZipEntry entry, long limit) throws IOException {
        require(entry != null, "备份缺少数据文件");
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        copyEntry(zip, entry, output, limit);
        return new String(output.toByteArray(), StandardCharsets.UTF_8);
    }

    private static long copyEntry(ZipFile zip, ZipEntry entry, OutputStream output, long limit)
            throws IOException {
        java.util.zip.CRC32 crc = new java.util.zip.CRC32();
        try (InputStream raw = zip.getInputStream(entry);
             java.util.zip.CheckedInputStream input = new java.util.zip.CheckedInputStream(raw, crc)) {
            long size = copy(input, output, limit);
            require(size == entry.getSize() && crc.getValue() == entry.getCrc(), "文件校验失败");
            return size;
        }
    }

    static long copy(InputStream input, OutputStream output, long limit) throws IOException {
        byte[] buffer = new byte[32768];
        long total = 0;
        for (int count; (count = input.read(buffer)) != -1;) {
            total += count;
            require(total <= limit, "备份文件过大");
            output.write(buffer, 0, count);
        }
        return total;
    }

    private static void add(ZipOutputStream zip, String name, byte[] data) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(data);
        zip.closeEntry();
    }

    private static void require(boolean condition, String error) throws IOException {
        if (!condition) throw new IOException(error);
    }
}
