const roomArtwork='reading-room.webp';
const themeDefaults={background:'room',opacity:84,font:'serif',ink:'#342b22',surface:'paper',weather:'sun',wind:true};
const themeArt={room:roomArtwork,autumn:'autumn-cafe.webp',none:''};
const themeFonts={
  serif:'"Noto Serif CJK SC","Songti SC",SimSun,serif',
  sans:'"Microsoft YaHei","Noto Sans CJK SC",system-ui,sans-serif',
  kai:'KaiTi,STKaiti,"Kaiti SC","Noto Serif CJK SC",serif'
};
const themeNames={sun:'晴天',rain:'雨天',cloud:'多云',storm:'雷雨',off:'静止'};
const scene=document.createElement('div');
scene.className='room-scene';
scene.setAttribute('aria-hidden','true');
scene.innerHTML='<div class="room-picture"></div><div class="room-weather"></div><div class="room-wind">'+
  Array.from({length:10},(_,i)=>'<i style="--i:'+i+'"></i>').join('')+'</div>';
document.body.prepend(scene);
let themeDraft=null, themeImport=null, bookMoving=false;
const savedTheme=()=>({...themeDefaults,...state.theme});
const reducedMotion=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function applyTheme(theme) {
  const root=document.documentElement;
  root.dataset.surface=theme.surface;
  scene.dataset.weather=theme.weather;
  scene.dataset.wind=String(theme.wind && theme.weather!=='off');
  scene.dataset.background=theme.background;
  const source=theme.background==='custom'?theme.image:themeArt[theme.background];
  const url=source?'url("'+source+'")':'none';
  root.style.setProperty('--room-image',url);
  root.style.setProperty('--room-opacity',theme.opacity/100);
  root.style.setProperty('--theme-font',themeFonts[theme.font]||themeFonts.serif);
  root.style.setProperty('--theme-ink',theme.ink);
}
applyTheme(savedTheme());
function themeForm(settings=savedTheme()) {
  themeDraft=settings;
  const opts=(data,selected)=>Object.entries(data).map(([key,label])=>'<option value="'+key+'" '+(key===selected?'selected':'')+'>'+label+'</option>').join('');
  sheet('theme','布置书房','<form id="theme-form" class="sheet-form theme-form">'+
    '<div class="theme-sample" id="theme-sample"><span>每一天</span></div>'+
    '<div class="two"><label class="compact-field">背景图片<select name="background">'+opts({room:'玻璃屋书房',autumn:'银杏窗边',mist:'雾蓝色墙',cream:'暖白纸面',none:'纯色',custom:'本机图片'},themeDraft.background)+'</select></label>'+
    '<label class="compact-field import-theme">本机图片<span class="quiet">选择图片</span><input type="file" id="theme-file" accept="image/*"></label></div>'+
    '<label class="compact-field">背景透明度 <output id="opacity-value">'+(100-themeDraft.opacity)+'%</output><input name="opacity" type="range" min="0" max="100" value="'+(100-themeDraft.opacity)+'"></label>'+
    '<div class="two"><label class="compact-field">主题字体<select name="font">'+opts({serif:'宋体 · 书刊',sans:'无衬线 · 清晰',kai:'楷体 · 手记'},themeDraft.font)+'</select></label>'+
    '<label class="compact-field">文字颜色<input name="ink" type="color" value="'+themeDraft.ink+'"></label></div>'+
    '<div class="two"><label class="compact-field">组件样式<select name="surface">'+opts({paper:'暖纸 · 装订',linen:'亚麻 · 清爽',glass:'雾面 · 通透'},themeDraft.surface)+'</select></label>'+
    '<label class="compact-field">窗外天气<select name="weather">'+opts(themeNames,themeDraft.weather)+'</select></label></div>'+
    '<label class="wind-control"><input name="wind" type="checkbox" '+(themeDraft.wind?'checked':'')+'> 微风与飘叶</label>'+
    '<div class="tools">'+button('theme-reset','恢复默认')+'<button class="sheet-primary">保存主题</button></div></form>');
  refreshThemeSample();
}
function refreshThemeSample() {
  const sample=document.querySelector('#theme-sample');
  if(sample){
    sample.dataset.background=themeDraft.background;
    sample.style.setProperty('--sample-veil',1-themeDraft.opacity/100);
    sample.style.color=themeDraft.ink;
  }
  scene.dataset.background=themeDraft.background;
}
const closeBeforeTheme=closeSheet;
closeSheet=function(){
  const themed=sheetTop()?.dataset.kind==='theme';
  closeBeforeTheme();
  if(themed && sheetTop()?.dataset.kind!=='theme'){
    themeDraft=null;
    const settings=savedTheme();
    applyTheme(settings);
    const label=view.querySelector('.weather-label');
    if(label)label.innerHTML='<span aria-hidden="true">✧</span> '+themeNames[settings.weather];
  }
};
scene.dataset.background=savedTheme().background;
view.addEventListener('input',event=>{
  const form=event.target.form;
  if(form?.id!=='theme-form'||event.target.id==='theme-file')return;
  const data=new FormData(form);
  const background=data.get('background');
  if(background==='custom'&&!themeDraft.image){
    form.elements.background.value=themeDraft.background;
    document.querySelector('#theme-file').click();
    return;
  }
  Object.assign(themeDraft,{background,opacity:100-Number(data.get('opacity')),font:data.get('font'),
    ink:data.get('ink'),surface:data.get('surface'),weather:data.get('weather'),wind:data.has('wind')});
  form.querySelector('#opacity-value').textContent=(100-themeDraft.opacity)+'%';
  applyTheme(themeDraft);
  refreshThemeSample();
});
view.addEventListener('change',async event=>{
  const input=event.target;
  if(input.id!=='theme-file'||!input.files[0])return;
  const url=URL.createObjectURL(input.files[0]);
  const job={};
  themeImport=job;
  try {
    const img=new Image();
    img.src=url;
    await img.decode();
    if(!input.isConnected||themeImport!==job)return;
    const factor=Math.min(1,1000/Math.max(img.naturalWidth,img.naturalHeight));
    const canvas=document.createElement('canvas');
    canvas.width=Math.max(1,Math.round(img.naturalWidth*factor));
    canvas.height=Math.max(1,Math.round(img.naturalHeight*factor));
    const ctx=canvas.getContext('2d');
    ctx.fillStyle='#eee6d6';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.drawImage(img,0,0,canvas.width,canvas.height);
    themeDraft.image=canvas.toDataURL('image/jpeg',.78);
    themeDraft.background='custom';
    input.form.elements.background.value='custom';
    applyTheme(themeDraft);
    refreshThemeSample();
  }catch{notify('无法读取这张背景图片');}
  finally{URL.revokeObjectURL(url);if(themeImport===job)themeImport=null;}
});
view.addEventListener('submit',event=>{
  if(event.target.id!=='theme-form')return;
  event.stopImmediatePropagation();
  event.preventDefault();
  if(themeImport){notify('背景正在导入');return;}
  if(commit(next=>next.theme=themeDraft)){closeSheet();notify('主题已保存');}
},true);

const renderShelf=screenShelf, renderBook=screenBook, backBeforeTheme=goBack;
screenShelf=function(returning) {
  renderShelf(returning);
  document.body.classList.add('in-library');
  view.querySelector('.top').insertAdjacentHTML('beforeend',button('theme','◐ 布置书房','room-settings'));
  const bookshelf=view.querySelector('.case');
  bookshelf.insertAdjacentHTML('afterbegin','<div class="cabinet-cap"></div>');
  if(state.books.length<=3)bookshelf.insertAdjacentHTML('beforeend','<div class="cabinet-display" aria-hidden="true"><i class="shelf-stack"></i><i class="shelf-vase"></i></div><div class="plank"></div>');
  bookshelf.insertAdjacentHTML('afterend','<div class="room-caption">'+
    button('theme','<span aria-hidden="true">✧</span> '+themeNames[savedTheme().weather],'weather-label')+(device?.exportBackup?button('backup','备份与恢复','weather-label'):'')+'</div>');
};
function shelfTile(id) {
  return [...view.querySelectorAll('.book')].find(tile=>tile.dataset.id===id);
}
const motionTime={open:860,close:830,leaf:630};
function transitionBook(book, from, to, closing) {
  const [color,mark]=covers[book.cover];
  const piece=document.createElement('div');
  piece.className='book-travel '+(closing?'closing':'opening');
  piece.setAttribute('aria-hidden','true');
  piece.style.cssText='--coat:'+color+';left:'+to.left+'px;top:'+to.top+'px;width:'+to.width+'px;height:'+to.height+'px';
  piece.style.setProperty('--dx',from.left-to.left+'px');
  piece.style.setProperty('--dy',from.top-to.top+'px');
  piece.style.setProperty('--sx',from.width/to.width);
  piece.style.setProperty('--sy',from.height/to.height);
  piece.innerHTML='<div class="travel-book"><div class="travel-paper"></div><div class="travel-board"><span>'+mark+'</span><strong>'+esc(book.name)+'</strong></div></div>';
  document.body.append(piece);
  return piece;
}
function spreadRect() {
  const width=Math.min(310,innerWidth*.78), height=Math.min(420,innerHeight*.62);
  return {left:(innerWidth-width)/2,top:(innerHeight-height)/2,width,height};
}
function enterBook(tile) {
  if(bookMoving)return;
  const book=state.books.find(b=>b.id===tile.dataset.id);
  if(!book)return;
  function reveal(){
    current=book.id;
    date=today();
    renderBook();
    document.body.classList.remove('in-library');
    window.scrollTo(0,0);
  }
  if(reducedMotion()){reveal();return;}
  bookMoving=true;
  const piece=transitionBook(book,tile.getBoundingClientRect(),spreadRect(),false);
  tile.classList.add('travel-hole');
  setTimeout(reveal,600);
  setTimeout(()=>{piece.remove();bookMoving=false;},motionTime.open);
}
function leaveBook(){
  if(bookMoving)return;
  const book=activeBook();
  if(!book){screenShelf();return;}
  if(reducedMotion()){screenShelf(book.id);return;}
  bookMoving=true;
  const from=spreadRect();
  const cover=transitionBook(book,from,from,true);
  setTimeout(()=>{
    screenShelf();
    const tile=shelfTile(book.id);
    tile?.scrollIntoView({block:'nearest'});
    if(!tile){cover.remove();bookMoving=false;return;}
    const rect=tile.getBoundingClientRect();
    tile.classList.add('travel-hole');
    cover.animate([{transform:'none'},{transform:'translate('+(rect.left-from.left)+'px,'+(rect.top-from.top)+'px) scale('+(rect.width/from.width)+','+(rect.height/from.height)+')'}],
      {duration:360,easing:'cubic-bezier(.45,.02,.3,1)',fill:'forwards'});
    setTimeout(()=>{tile.classList.remove('travel-hole');cover.remove();bookMoving=false;},360);
  },motionTime.close-360);
}
screenBook=function(animation='') {
  const previous=animation==='flip'&&view.querySelector('.bound');
  const shot=previous&&!reducedMotion()?previous.cloneNode(true):null;
  const rect=shot&&previous.getBoundingClientRect();
  renderBook(shot?'':animation);
  document.body.classList.remove('in-library');
  if(!shot||!view.querySelector('.bound'))return;
  const paper=document.createElement('div');
  paper.className='page-turn-overlay '+(flipDirection<0?'backwards':'');
  paper.setAttribute('aria-hidden','true');
  paper.style.cssText='left:'+rect.left+'px;top:'+rect.top+'px;width:'+rect.width+'px;height:'+Math.min(rect.height,innerHeight-Math.max(0,rect.top))+'px';
  paper.append(shot);
  document.body.append(paper);
  setTimeout(()=>paper.remove(),motionTime.leaf);
};
goBack=function(){
  if(!sheetTop()&&!imageName&&current&&!document.querySelector('#focus-value,#book-form,#photo-view')){
    leaveBook();return;
  }
  backBeforeTheme();
};
view.addEventListener('click',event=>{
  const target=event.target.closest('[data-action]');
  if(!target)return;
  switch(target.dataset.action){
    case 'backup':
      sheet('backup','备份与恢复','<div class="backup-options"><p>把书架、流水、计时、配图和主题保存为一个 ZIP 文件。换手机时，在新手机上选择同一个文件。</p>'+
        button('export-backup','导出备份','sheet-primary')+button('import-backup','从备份恢复','quiet')+'<small>备份文件含有个人记录。恢复前会显示文件内容，并请你确认是否替换现有数据。</small></div>');
      break;
    case 'export-backup':
      if(commit(()=>{})){closeSheet();device.exportBackup();}
      break;
    case 'import-backup':
      closeSheet();device.importBackup();
      break;
    case 'theme':
      if(!bookMoving)themeForm();
      break;
    case 'theme-reset':
      closeBeforeTheme();
      themeForm({...themeDefaults});
      applyTheme(themeDraft);
      break;
    case 'open': enterBook(target);break;
    case 'shelf': leaveBook();break;
    default: return;
  }
  event.stopImmediatePropagation();
},true);
screenShelf();
