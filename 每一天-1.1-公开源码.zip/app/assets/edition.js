const originalShelf = screenShelf;
const originalBack = goBack;
const originalBook = screenBook;
const originalClock = updateClock;
let mode = '', flipDirection = 1;
const palette = ['#668477','#c18b62','#81819b','#849ea5','#ad7776','#aa965c'];
const weekdays = '日一二三四五六';
const localDate = key => new Date(key+'T12:00:00');
const offset = (key,n) => {const d=localDate(key);d.setDate(d.getDate()+n);return day(d);};
const shortDate = key => key.slice(5).replace('-',' 月 ')+' 日';
const sum = (items,field) => items.reduce((a,e)=>a+(e[field]||0),0);
const currency = value => (value/100).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2});
const duration = ms => {
  const n=Math.floor(ms/60000);
  return n? (n>=60?Math.floor(n/60)+' 小时 ':'')+(n%60)+' 分钟':Math.floor(ms/1000)+' 秒';
};
const tab = (name,title) => button('mode:'+name,title,'tab '+(mode===name?'selected':''));
const taskList = book => book.tasks||[];
const sorted = list => list.slice().sort((a,b)=>a.time-b.time);

screenShelf = function(returning) {
  mode='';
  originalShelf(returning);
  view.dataset.book='shelf';
  view.querySelector('.top').insertAdjacentHTML('afterend','<div class="shelf-label"><span>我的书架</span><span>'+state.books.length+' 本</span></div>');
};

function diaryPage(book, entries, archive, animation) {
  if(archive) {
    const dates = [...new Set(book.entries.map(e=>e.day))].sort();
    const page = dates.indexOf(date);
    const hero = entries.flatMap(e=>e.photos||[])[0];
    const image = hero && device ? '<img src="'+esc(device.path(hero))+'" alt="日记页首照片">' : '';
    return '<section class="bound" id="gesture"><div class="chapter-hero '+(image?'has-photo':'')+'">'+image+
      '<div><small>'+date.slice(0,4)+'　周'+weekdays[localDate(date).getDay()]+'</small><strong>'+shortDate(date)+'</strong></div></div>'+
      '<div class="chapter-text">'+(entries.length?entries.map(e=>diaryRow(e,true,hero)).join(''):'<p class="empty">这一页还没有手记。</p>')+
      '<footer class="page-index">'+(page>=0?(page+1)+' / '+dates.length:'')+'</footer></div></section>'+
      '<nav class="pager">'+button('archive:-1','‹ 上一页')+button('archive:0','最近一页')+button('archive:1','下一页 ›')+'</nav>';
  }
  return '<div class="dates-top"><strong>'+date.slice(0,4)+' 年 '+Number(date.slice(5,7))+' 月</strong>'+
    button('open-date','▦ '+date.replace(/-/g,' / '),'date-trigger')+'</div>'+
    '<nav class="wheel '+(animation==='wheel'?'wheel-moving '+(flipDirection<0?'reverse':''):'')+'" id="gesture" aria-label="左右滑动选择日期">'+button('day:-1','‹','wheel-arrow')+
    [-2,-1,0,1,2].map(i=>{
      const key=offset(date,i);
      return '<button class="date-chip '+(!i?'current':'')+'" data-action="pick-day:'+key+'" style="--tag:'+palette[(localDate(key).getDate()-1)%palette.length]+'" '+(!i?'aria-current="date"':'')+
        '><small>'+(key===today()?'今天':'周'+weekdays[localDate(key).getDay()])+'</small><b>'+Number(key.slice(-2))+'</b><i>'+(book.entries.some(e=>e.day===key)?'•':'&nbsp;')+'</i></button>';
    }).join('')+button('day:1','›','wheel-arrow')+'</nav>'+
    '<section class="leaf timeline"><header><h3>'+(date===today()?'今天的手记':shortDate(date)+'的手记')+'</h3><small>'+entries.length+' 则</small></header>'+
    (entries.length?entries.map(e=>diaryRow(e,false)).join(''):'<p class="empty">这一天的故事，等你写下。</p>')+
    '</section>';
}
function diaryRow(entry, archive, hero) {
  const photos=(entry.photos||[]).filter(name=>name!==hero);
  return '<article class="moment"><time>'+stamp(entry.time)+'</time><div>'+
    (entry.text?'<p>'+esc(entry.text)+'</p>':'')+
    (photos.length&&device?'<div class="photos">'+photos.map(n=>photoTag(n)).join('')+'</div>':'')+
    (archive?'':'<details class="entry-actions"><summary>操作</summary>'+button('edit:'+entry.id,'编辑')+' '+button('delete:'+entry.id,'删除','quiet danger')+'</details>')+'</div></article>';
}
function archiveStep(delta) {
  const dates=[...new Set(activeBook().entries.map(e=>e.day))].sort();
  const next=delta<0?dates.filter(d=>d<date).pop():delta>0?dates.find(d=>d>date):dates[dates.length-1];
  if(!next || next===date){if(delta)notify(delta<0?'已经是最早一页':'已经是最后一页');return;}
  date=next;
  flipDirection=delta||1;
  screenBook('flip');
}

function cashTotals(entries) {
  return [sum(entries.filter(e=>e.income),'cents'),sum(entries.filter(e=>!e.income),'cents')];
}
function ledger(book, entries) {
  const month=localDate(date);
  const start=day(new Date(month.getFullYear(),month.getMonth(),1));
  const days=new Date(month.getFullYear(),month.getMonth()+1,0).getDate();
  const monthEntries=book.entries.filter(e=>e.day.slice(0,7)===date.slice(0,7));
  const monthLabel=month.getFullYear()+' 年 '+(month.getMonth()+1)+' 月';
  const controls='<div class="month-control">'+button('month:-1','‹','icon-button') +button('open-date:month',monthLabel+' ▾','date-trigger')+button('month:1','›','icon-button')+'</div>';
  if(mode==='money-report')return reportPage(book);
  let cells='<span></span>'.repeat((localDate(start).getDay()+6)%7);
  for(let i=0;i<days;i++){
    const key=offset(start,i);
    const [received,spent]=cashTotals(monthEntries.filter(e=>e.day===key));
    cells+='<button class="calendar-day '+(key===date?'chosen':'')+'" data-action="pick-day:'+key+'" '+(key===date?'aria-current="date"':'')+'><b>'+(i+1)+'</b>'+
      (received?'<small class="positive">+'+currency(received)+'</small>':'')+
      (spent?'<small class="negative">−'+currency(spent)+'</small>':'')+'</button>';
  }
  const [received,spent]=cashTotals(entries);
  return '<section class="leaf calendar">'+controls+'<nav aria-label="流水日历" class="calendar-grid">'+
    [...'一二三四五六日'].map(d=>'<span class="weekday">'+d+'</span>').join('')+cells+'</nav></section>'+
    '<section class="leaf"><header><div><h3>'+shortDate(date)+'</h3><small>收入 '+currency(received)+'　支出 '+currency(spent)+'</small></div>'+button('new-entry','＋ 记一笔','action')+'</header>'+
    (entries.length?entries.slice().reverse().map(e=>'<article class="transaction"><div class="txn-icon '+(e.income?'positive':'negative')+'">'+categoryIcon(e.category,e.income)+'</div><div><b>'+esc(e.text||e.category||(e.income?'收入':'支出'))+'</b><small>'+esc(e.category||(e.income?'收入':'支出'))+' · '+stamp(e.time)+'</small></div><strong class="'+(e.income?'positive':'negative')+'">'+(e.income?'+':'−')+currency(e.cents)+'</strong><details class="entry-actions"><summary aria-label="操作">···</summary>'+button('edit:'+e.id,'编辑')+' '+button('delete:'+e.id,'删除','quiet danger')+'</details></article>').join(''):'<p class="empty">当天没有流水，可以补记一笔。</p>')+'</section>';
}
function bars(points, format) {
  const max=Math.max(1,...points.map(p=>p[1]));
  return '<div class="bar-chart">'+points.map(([label,value])=>'<div><small>'+esc(value?format(value):'—')+'</small>'+
    '<div class="bar-track"><i style="--height:'+Math.max(value?4:0,value/max*100)+'%"></i></div><span>'+esc(label)+'</span></div>').join('')+'</div>';
}
function breakdown(items,field,label,format) {
  const groups=new Map();
  for(const item of items){const key=label(item);groups.set(key,(groups.get(key)||0)+item[field]);}
  const parts=[...groups].sort((a,b)=>b[1]-a[1]);
  const total=sum(items,field);
  if(!total)return '<p class="empty">还没有可统计的记录。</p>';
  let position=0;
  const stops=parts.map(([,n],i)=>{
    const start=position;position+=n/total*100;
    return palette[i%palette.length]+' '+start+'% '+position+'%';
  });
  return '<div class="distribution"><div class="donut" aria-hidden="true" style="--parts:'+stops.join(',')+'"></div>'+
    '<div class="legend">'+parts.map(([name,n],i)=>'<div><i style="--tag:'+palette[i%palette.length]+'"></i><span>'+esc(name)+'</span><b>'+format(n)+'</b></div>').join('')+'</div></div>';
}

function focusPage(book) {
  if(mode==='timer-focus-report')return reportPage(book);
  const running=state.timer;
  return '<section class="leaf task-sheet"><header><div><h3>专注任务</h3><small>今日累计 '+duration(sum(book.entries.filter(e=>e.day===today()),'ms'))+'</small></div>'+button('new-task','＋ 新任务','action')+'</header>'+
    (running&&running.book===book.id?'<div class="ongoing">'+button('resume-focus','返回计时 · '+esc(running.text),'action')+'</div>':'')+
    (taskList(book).length?taskList(book).map((task,i)=>'<article class="task" style="--tag:'+palette[i%palette.length]+'"><div><b>'+esc(task.name)+'</b><small>'+
    (task.minutes?'倒计时 · '+task.minutes+' 分钟':'正计时')+'</small></div><div>'+button('edit-task:'+task.id,'设置','task-edit')+' '+button('launch-task:'+task.id,'开始','task-start')+'</div></article>').join(''):'<p class="empty">添加阅读、学习或工作任务，随时开始计时。</p>')+
    '</section>';
}
function taskSetup(task) {
  view.innerHTML='<header class="chapter-nav">'+button('return-book','‹ 返回','nav-back')+'<h2>'+(task?'任务设置':'新建任务')+'</h2></header>'+
    '<form id="task-form" class="leaf" data-id="'+(task?.id||'')+'"><label>任务名称<input name="name" maxlength="60" required value="'+esc(task?.name)+'" placeholder="例如 整理论文资料"></label>'+
    '<label>计时方式<select name="mode"><option value="up">正计时</option><option value="down" '+(task?.minutes?'selected':'')+'>倒计时</option></select></label>'+
    '<label>倒计时分钟数<input name="minutes" type="number" min="1" max="720" value="'+(task?.minutes||25)+'" '+(task?.minutes?'':'disabled')+'></label>'+
    '<div class="tools"><button class="action">保存任务</button>'+(task?button('remove-task:'+task.id,'删除任务','quiet danger'):'')+'</div></form>';
}
function focusElapsed(timer, now=Date.now()) {
  return (timer.segments||[]).reduce((n,s)=>n+s[1]-s[0],0)+(timer.paused?0:Math.max(0,now-timer.start));
}
function focusClock() {
  const timer=state.timer;
  view.innerHTML='<section class="focus-screen"><header>'+button('return-book','‹ 返回任务','glass')+'<span>'+(timer.limit?'倒计时':'正计时')+'</span></header>'+
    '<div class="focus-dial" id="dial"><div><small>'+esc(timer.text)+'</small><strong id="focus-value">00:00</strong><span id="focus-state"></span></div></div>'+
    '<div class="focus-buttons">'+button('toggle-focus',timer.paused?'继续':'暂停','glass')+button('save-focus','结束并保存','finish')+'</div></section>';
  window.scrollTo(0,0);
  updateClock();
}
function saveFocus(elapsedTime) {
  const timer=state.timer;
  if(!timer)return;
  let remaining=elapsedTime;
  const segments=(timer.segments||[]).slice();
  if(!timer.paused)segments.push([timer.start,Date.now()]);
  const days=new Map();
  for(const [from,to] of segments){
    let start=from;
    while(start<to && remaining>0){
      const midnight=new Date(start);
      midnight.setHours(24,0,0,0);
      const length=Math.min(to-start,midnight.getTime()-start,remaining);
      const key=day(new Date(start));
      if(days.has(key))days.get(key).ms+=length;
      else days.set(key,{id:uid(),day:key,time:start,text:timer.text,ms:length});
      start+=length;
      remaining-=length;
    }
  }
  if(commit(next=>{
    next.books.find(book=>book.id===timer.book).entries.push(...days.values());
    next.timer=null;
  })){
    if(current===timer.book&&document.querySelector('#focus-value'))screenBook('open');
    notify(elapsedTime?'专注时间已写入统计':'计时已结束');
  }
}
updateClock = function() {
  originalClock();
  const timer=state.timer;
  const value=document.querySelector('#focus-value');
  if(!timer)return;
  const spent=focusElapsed(timer);
  if(value){
    const display=timer.limit?Math.max(0,timer.limit-spent):spent;
    const clock=elapsed(timer.limit?Math.ceil(display/1000)*1000:display);
    value.textContent=clock.startsWith('00:')?clock.slice(3):clock;
    document.querySelector('#focus-state').textContent=timer.paused?'已暂停':'专注中';
    document.querySelector('#dial').style.setProperty('--progress',(timer.limit?Math.max(0,1-spent/timer.limit):spent%60000/60000)*360+'deg');
  }
  if(timer.limit&&spent>=timer.limit&&Date.now()>(timer.retry||0)){
    timer.retry=Date.now()+5000;
    saveFocus(timer.limit);
  }
};
screenBook = function(animation='') {
  const book=activeBook();
  if(!book){screenShelf();return;}
  if(!mode||!mode.startsWith(book.type))mode=book.type;
  const entries=sorted(book.entries.filter(e=>e.day===date));
  view.dataset.book=book.type;
  const tabs=book.type==='diary'?tab('diary','当天手记')+tab('diary-archive','旧日书页'):
    book.type==='timer'?tab('timer','任务')+tab('timer-focus-report','专注统计'):
    tab('money','流水日历')+tab('money-report','收支报表');
  const contents=book.type==='diary'?diaryPage(book,entries,mode==='diary-archive',animation):
    book.type==='timer'?focusPage(book):ledger(book,entries);
  view.innerHTML='<header class="chapter-nav">'+button('shelf','‹ 书架','nav-back')+'<h2>'+esc(book.name)+'</h2>'+button('settings','封面','nav-back')+'</header>'+
    '<nav class="tabs">'+tabs+'</nav><div class="chapter-content '+(animation==='flip'?'turning '+(flipDirection<0?'reverse':''):animation==='wheel'?'':animation)+'">'+contents+'</div>';
  bindSwipe();
  if(animation)window.scrollTo(0,0);
};
function bindSwipe(){
  const area=document.querySelector('#gesture');
  if(!area)return;
  let x,y;
  area.addEventListener('pointerdown',e=>{x=e.clientX;y=e.clientY;});
  area.addEventListener('pointerup',e=>{
    const dx=e.clientX-x,dy=e.clientY-y;
    if(Math.abs(dx)<35||Math.abs(dx)<Math.abs(dy))return;
    const direction=dx<0?1:-1;
    area.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();},{capture:true,once:true});
    if(mode==='diary-archive')archiveStep(direction);
    else{date=offset(date,direction);flipDirection=direction;screenBook('wheel');}
  });
}
goBack = function(){
  if(document.querySelector('#focus-value')||document.querySelector('#task-form')){screenBook();return;}
  originalBack();
};
view.addEventListener('change',event=>{
  if(event.target.name==='mode'&&event.target.form?.id==='task-form'){
    event.target.form.elements.minutes.disabled=event.target.value==='up';
  }
});
view.addEventListener('submit',event=>{
  if(event.target.id!=='task-form')return;
  event.stopImmediatePropagation();
  event.preventDefault();
  const data=new FormData(event.target);
  const name=data.get('name').trim();
  if(!name){notify('请输入任务名称');return;}
  const old=event.target.dataset.id;
  if(commit(next=>{
    const book=next.books.find(b=>b.id===current);
    const tasks=book.tasks||(book.tasks=[]);
    const task={id:old||uid(),name,minutes:data.get('mode')==='down'?Number(data.get('minutes')):0};
    if(old)tasks[tasks.findIndex(t=>t.id===old)]=task;
    else tasks.push(task);
  }))screenBook();
},true);
view.addEventListener('click',event=>{
  const target=event.target.closest('[data-action]');
  if(!target)return;
  const [action,arg]=target.dataset.action.split(':');
  const book=activeBook();
  switch(action){
    case 'mode':
      mode=arg;
      if(mode==='diary-archive'){
        const last=book.entries.map(e=>e.day).filter(d=>d<=date).sort().pop();
        if(last)date=last;
      }else if(mode==='diary')date=today();
      screenBook('open');
      break;
    case 'day': flipDirection=Number(arg);date=offset(date,flipDirection);screenBook('wheel');break;
    case 'pick-day': date=arg;screenBook();break;
    case 'archive': archiveStep(Number(arg));break;
    case 'month': {
      const d=localDate(date);
      date=day(new Date(d.getFullYear(),d.getMonth()+Number(arg),1));
      screenBook('flip');
      break;
    }
    case 'new-task': taskSetup();break;
    case 'edit-task': taskSetup(taskList(book).find(t=>t.id===arg));break;
    case 'remove-task':
      if(window.confirm('删除这个任务？已有专注记录会保留。')&&commit(next=>{
        const b=next.books.find(b=>b.id===current);
        b.tasks=b.tasks.filter(t=>t.id!==arg);
      }))screenBook();
      break;
    case 'return-book': screenBook();break;
    case 'launch-task': {
      if(state.timer){notify('请先结束正在运行的计时');break;}
      const task=taskList(book).find(t=>t.id===arg);
      if(commit(next=>next.timer={book:book.id,text:task.name,start:Date.now(),limit:task.minutes*60000,segments:[],paused:false}))focusClock();
      break;
    }
    case 'resume-focus': focusClock();break;
    case 'toggle-focus': {
      const now=Date.now();
      if(commit(next=>{
        const t=next.timer;
        if(t.paused){t.start=now;t.paused=false;}
        else{(t.segments||(t.segments=[])).push([t.start,Math.max(t.start,now)]);t.paused=true;}
      }))focusClock();
      break;
    }
    case 'save-focus': saveFocus(Math.min(state.timer.limit||Infinity,focusElapsed(state.timer)));break;
    default: return;
  }
  event.stopImmediatePropagation();
});
screenShelf();

