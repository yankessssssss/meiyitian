const defaultCategories = {
  out:[['餐饮','🥢'],['交通','🚇'],['购物','🛍'],['生活','⌂'],['学习','▤'],['娱乐','♫'],['其他','◇']],
  in:[['工资','▣'],['兼职','✦'],['礼金','♡'],['退款','↶'],['其他收入','◇']]
};
const iconOptions=['🥢','☕','🚇','🛍','⌂','▤','♫','✦','♡','▣','↶','◇','🍃','✈','▧','✚'];
const categories = direction => state.categories?.[direction] || defaultCategories[direction].map(([name,icon])=>({name,icon}));
let categoryDirection='out', categoryEditing=null, categoryArtwork='';
let reportScope={money:'month',timer:'month'};
let datePicker=null, quickNote=null, photoTarget='';
const inheritedBook=screenBook, inheritedBack=goBack, inheritedEdit=editEntry, inheritedTask=taskSetup;
const inheritedPhotoReady=photoReady, inheritedPhotoFailed=photoFailed, inheritedPhotoCancelled=photoCancelled;
const sheetTop = () => [...view.querySelectorAll('dialog[open]')].pop();
const inheritedNotice=notify;
let sheetNoticeTimer;
notify=function(message) {
  const dialog=sheetTop();
  if(!dialog){inheritedNotice(message);return;}
  let status=dialog.querySelector('.sheet-status');
  if(!status){
    status=document.createElement('div');
    status.className='sheet-status';
    status.setAttribute('role','status');
    dialog.append(status);
  }
  status.textContent=message;
  clearTimeout(sheetNoticeTimer);
  sheetNoticeTimer=setTimeout(()=>status.remove(),2600);
};
function sheet(kind,title,content) {
  const dialog=document.createElement('dialog');
  dialog.className='bottom-sheet';
  dialog.dataset.kind=kind;
  dialog.innerHTML='<div class="sheet-grip" aria-hidden="true"></div><header class="sheet-title"><h3>'+title+'</h3>'+button('close-sheet','×','sheet-close')+'</header>'+content;
  view.append(dialog);
  dialog.addEventListener('cancel',event=>{event.preventDefault();closeSheet();});
  dialog.addEventListener('click',event=>{if(event.target===dialog){
    const box=dialog.getBoundingClientRect();
    if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)closeSheet();
  }});
  dialog.showModal();
  dialog.querySelector('.sheet-close').focus({preventScroll:true});
  return dialog;
}
function closeSheet() {
  if(imagePending){notify('请等图片导入完成');return;}
  const dialog=sheetTop();
  if(!dialog)return;
  if(dialog.dataset.kind==='entry')clearDraft();
  dialog.close();
  dialog.remove();
}
function iconMarkup(icon) {
  return icon?.startsWith('data:image/jpeg;base64,')?'<img class="category-art" src="'+esc(icon)+'" alt="">':esc(icon||'◇');
}
function categoryIcon(name,income) {
  return iconMarkup(categories(income?'in':'out').find(c=>c.name===name)?.icon);
}
function categoryGrid(direction,selected) {
  const list=categories(direction).slice();
  if(selected&&!list.some(c=>c.name===selected))list.push({name:selected,icon:'◇'});
  return list.map(c=>'<label class="category-choice"><input type="radio" name="category" value="'+esc(c.name)+'" '+(c.name===selected?'checked':'')+
    ' required><span><i>'+iconMarkup(c.icon)+'</i><b>'+esc(c.name)+'</b></span></label>').join('');
}
function moneySheet(entry) {
  const direction=entry?.income?'in':'out';
  draft={id:entry?.id,photos:[],added:[]};
  sheet('entry',entry?'编辑流水':'记一笔','<form id="entry-form" class="sheet-form money-form">'+
    '<div class="segmented" aria-label="收支">'+[['out','支出'],['in','收入']].map(([key,label])=>
      '<label><input type="radio" name="direction" value="'+key+'" '+(direction===key?'checked':'')+'><span>'+label+'</span></label>').join('')+'</div>'+
    '<label class="amount-box"><small>金额</small><span><strong>¥</strong><input name="amount" type="text" inputmode="decimal" required placeholder="0.00" value="'+(entry?amount(entry.cents):'')+'" aria-label="金额"></span></label>'+
    '<div class="category-heading"><strong>分类</strong>'+button('manage-categories','管理分类','text-button')+'</div>'+
    '<div class="category-grid" id="category-grid">'+categoryGrid(direction,entry?.category)+'</div>'+
    '<label class="compact-field"><span>备注 <small>选填</small></span><input name="text" value="'+esc(entry?.text)+'" maxlength="160" placeholder="记下用途或来源"></label>'+
    '<button class="sheet-primary">保存流水</button></form>');
}
function categoryManager(direction) {
  categoryDirection=direction;
  const title=direction==='in'?'收入分类':'支出分类';
  sheet('categories',title,'<div class="category-manager"></div>');
  refreshCategoryManager();
}
function refreshCategoryManager() {
  const container=view.querySelector('.category-manager');
  if(!container)return;
  container.innerHTML=categories(categoryDirection).map((c,i)=>
    '<div class="category-line"><span class="category-badge">'+iconMarkup(c.icon)+'</span><b>'+esc(c.name)+'</b>'+
    button('change-category:'+i,'编辑','text-button')+button('remove-category:'+i,'删除','text-button danger')+'</div>').join('')+
    button('change-category:-1','＋ 新分类','sheet-primary');
}
function categoryEditor(index) {
  const c=categories(categoryDirection)[index];
  categoryEditing=c?.name||null;
  categoryArtwork=c?.icon?.startsWith('data:')?c.icon:'';
  sheet('category-editor',c?'编辑分类':'新建分类','<form class="sheet-form" id="category-form">'+
    '<label class="compact-field">分类名称<input name="name" maxlength="16" required value="'+esc(c?.name)+'"></label>'+
    '<div class="category-heading"><strong>图标</strong><label class="text-button icon-import">导入图片<input type="file" accept="image/*" id="icon-file"></label></div>'+
    '<div class="icon-picker">'+iconOptions.map((icon,i)=>'<label><input type="radio" name="icon" value="'+icon+'" '+(!categoryArtwork&&(c?.icon===icon||(!iconOptions.includes(c?.icon)&&i===0))?'checked':'')+'><span>'+icon+'</span></label>').join('')+
    '<span id="imported-icon">'+(categoryArtwork?iconMarkup(categoryArtwork):'')+'</span></div>'+
    '<button class="sheet-primary">保存分类</button></form>');
}
function syncMoneyGrid(selected) {
  const form=view.querySelector('.money-form');
  if(!form)return;
  const choice=selected??form.querySelector('[name=category]:checked')?.value;
  form.querySelector('#category-grid').innerHTML=categoryGrid(form.elements.direction.value,choice);
}
function openTask(task) {
  const page=document.createDocumentFragment();
  while(view.firstChild)page.append(view.firstChild);
  inheritedTask(task);
  const form=view.querySelector('#task-form');
  view.replaceChildren(page);
  form.className='sheet-form task-form';
  const select=form.elements.mode;
  select.closest('label').outerHTML='<div class="segmented" aria-label="计时方式">'+[['up','正计时'],['down','倒计时']].map(([key,label])=>
    '<label><input type="radio" name="mode" value="'+key+'" '+((task?.minutes?'down':'up')===key?'checked':'')+'><span>'+label+'</span></label>').join('')+'</div>';
  form.elements.minutes.closest('label').hidden=!task?.minutes;
  form.querySelector('button.action').className='sheet-primary';
  const dialog=sheet('task',task?'任务设置':'新建任务','');
  dialog.append(form);
}
taskSetup=openTask;
editEntry=function(entry) {
  if(activeBook()?.type==='money'){moneySheet(entry);return;}
  const page=document.createDocumentFragment();
  while(view.firstChild)page.append(view.firstChild);
  inheritedEdit(entry);
  const form=view.querySelector('#entry-form');
  view.replaceChildren(page);
  form.className='sheet-form';
  form.querySelector('button.action').className='sheet-primary';
  if(device?.camera)form.querySelector('[data-action=photo]').insertAdjacentHTML('afterend',button('entry-camera','拍照'));
  sheet('entry','编辑手记','').append(form);
};

function resetQuickNote() {
  if(quickNote&&device)quickNote.photos.forEach(n=>device.remove(n));
  quickNote=null;
}
screenBook=function(animation='') {
  const changing=quickNote&&(quickNote.key!==date||quickNote.book!==current);
  if(changing)resetQuickNote();
  inheritedBook(animation);
  const chart=view.querySelector('.report-chart[data-latest]');
  if(chart){
    const point=chart.querySelectorAll('.bar-chart>div')[Number(chart.dataset.latest)];
    if(point)chart.scrollLeft+=point.getBoundingClientRect().right-chart.getBoundingClientRect().right+8;
  }
  if(activeBook()?.type==='diary'){
    quickNote ||= {key:date,book:current,text:'',photos:[]};
    view.insertAdjacentHTML('beforeend','<form class="note-dock" id="quick-note"><label class="sr-only" for="quick-text">写一则手记</label>'+
      '<textarea id="quick-text" name="text" rows="1" placeholder="写一则手记…">'+esc(quickNote.text)+'</textarea>'+
      '<div id="quick-photos" class="photos"></div><div class="note-actions">'+
      (device?button('quick-photo','▧ 图片','note-tool'):'')+(device?.camera?button('quick-camera','◉ 拍照','note-tool'):'')+
      '<button class="note-send" type="submit">写入本页</button></div></form>');
    drawQuickPhotos();
  }
};
const shelfBeforeComposer=screenShelf;
screenShelf=function(returning){resetQuickNote();shelfBeforeComposer(returning);};
function drawQuickPhotos() {
  const box=document.querySelector('#quick-photos');
  if(box)box.innerHTML=quickNote.photos.map(n=>'<div>'+photoTag(n)+button('quick-remove:'+n,'移除','text-button')+'</div>').join('');
}
function attachPhoto(source,target) {
  if(imagePending)return;
  imagePending=true;
  photoTarget=target;
  device[source]();
}
photoReady=function(name) {
  if(photoTarget==='quick'){
    imagePending=false;
    if(quickNote){quickNote.photos.push(name);drawQuickPhotos();}
    else device.remove(name);
  }else inheritedPhotoReady(name);
  photoTarget='';
};
photoCancelled=function(){photoTarget='';inheritedPhotoCancelled();};
photoFailed=function(){photoTarget='';inheritedPhotoFailed();};
goBack=function(){
  if(imageName){inheritedBack();return;}
  if(sheetTop()){closeSheet();return;}
  inheritedBack();
};

const precisionLabel={day:'日',month:'月',year:'年'};
const dateTitle=(key,scope)=>scope==='year'?key.slice(0,4)+' 年':scope==='month'?key.slice(0,4)+' 年 '+Number(key.slice(5,7))+' 月':key.slice(0,4)+' 年 '+shortDate(key);
function periodMove(key,scope,direction) {
  const d=localDate(key);
  if(scope==='day')return offset(key,direction);
  if(scope==='month')return day(new Date(d.getFullYear(),d.getMonth()+direction,1));
  return day(new Date(d.getFullYear()+direction,0,1));
}
function dateSheet(scope) {
  datePicker={scope,level:scope,key:date};
  sheet('date','选择'+({day:'日期',month:'月份',year:'年份'}[scope]),'<div id="date-options"></div>');
  renderDateSheet();
}
function renderDateSheet() {
  const {level:scope,key}=datePicker;
  const d=localDate(key);
  const year=d.getFullYear(), month=d.getMonth();
  const left=scope==='year'?year-6:year;
  const title=scope==='year'?left+'–'+(left+11):dateTitle(key,scope==='day'?'month':'year');
  const heading=scope==='year'?'<strong>'+title+'</strong>':button('picker-level:'+(scope==='day'?'month':'year'),title+' ▾','date-trigger');
  const top='<header class="picker-nav">'+button('picker-step:-1','‹','picker-arrow')+heading+button('picker-step:1','›','picker-arrow')+'</header>';
  let grid='';
  const cell=(value,label)=>button('confirm-date:'+value,label,'picker-cell '+(dateTitle(value,scope)===dateTitle(date,scope)?'picked':''));
  if(scope==='day'){
    const first=day(new Date(year,month,1));
    grid=[...'一二三四五六日'].map(x=>'<span>'+x+'</span>').join('')+'<span></span>'.repeat((localDate(first).getDay()+6)%7);
    for(let i=1;i<=new Date(year,month+1,0).getDate();i++)grid+=cell(offset(first,i-1),i);
  }else if(scope==='month'){
    for(let i=0;i<12;i++)grid+=cell(day(new Date(year,i,1)),(i+1)+' 月');
  }else{
    for(let i=left;i<left+12;i++)grid+=cell(day(new Date(i,0,1)),i);
  }
  view.querySelector('#date-options').innerHTML=top+'<div class="picker-grid '+scope+'">'+grid+'</div>'+
    '<div class="picker-footer">'+button('confirm-date:'+today(),scope==='day'?'今天':scope==='month'?'本月':'今年','text-button')+'</div>';
}
function reportPage(book) {
  const scope=reportScope[book.type], time=book.type==='timer';
  const period=date.slice(0,{day:10,month:7,year:4}[scope]);
  const entries=book.entries.filter(e=>e.day.startsWith(period));
  const tabs=Object.entries(precisionLabel).map(([key,label])=>button('report-scope:'+key,label,'report-tab '+(scope===key?'active':''))).join('');
  const nav='<div class="report-nav"><div class="report-selector" aria-label="统计范围">'+tabs+'</div><header>'+
    button('report-step:-1','‹','picker-arrow')+button('open-date:'+scope,dateTitle(date,scope)+' ▾','date-trigger')+button('report-step:1','›','picker-arrow')+'</header></div>';
  const format=time?duration:v=>'¥'+currency(v);
  const d=localDate(date);
  const first=day(new Date(d.getFullYear(),d.getMonth(),1));
  const count=scope==='year'?12:scope==='month'?new Date(d.getFullYear(),d.getMonth()+1,0).getDate():24;
  const field=time?'ms':'cents';
  const trendItems=time?entries:entries.filter(e=>!e.income);
  const points=Array.from({length:count},(_,i)=>{
    const subset=trendItems.filter(e=>scope==='day'?new Date(e.time).getHours()===i:scope==='month'?e.day===offset(first,i):Number(e.day.slice(5,7))===i+1);
    return [scope==='day'?String(i).padStart(2,'0')+' 时':scope==='month'?(i+1)+' 日':(i+1)+' 月',sum(subset,field)];
  });
  const latest=points.reduce((last,point,i)=>point[1]?i:last,-1);
  const [income,spent]=cashTotals(entries);
  const summary=time?
    '<div class="report-summary"><small>累计专注</small><strong>'+duration(sum(entries,'ms'))+'</strong><div>'+entries.length+' 次记录　·　'+new Set(entries.map(e=>e.day)).size+' 天有专注</div></div>':
    '<div class="report-summary"><small>结余</small><strong>¥ '+currency(income-spent)+'</strong><div>收入 ¥'+currency(income)+'　支出 ¥'+currency(spent)+'</div></div>';
  const breakdowns=time?'<h3>任务用时分布</h3>'+breakdown(entries,'ms',e=>e.text,format):
    '<h3>支出分类</h3>'+breakdown(trendItems,'cents',e=>e.category||'其他',format)+
    '<h3>收入来源</h3>'+breakdown(entries.filter(e=>e.income),'cents',e=>e.category||'其他收入',format);
  const logs=time&&entries.length?'<h3>专注明细</h3>'+sorted(entries).reverse().map(e=>'<div class="focus-log"><time>'+e.day.slice(5)+' '+stamp(e.time)+'</time><span>'+esc(e.text)+'</span><b>'+duration(e.ms)+'</b></div>').join(''):'';
  return nav+'<section class="bound report-book"><div class="report-header"><h3>'+(time?'专注手账':'收支账册')+'</h3><small>'+dateTitle(date,scope)+'</small></div>'+
    summary+'<h3>'+(time?'专注趋势':'支出走势')+'</h3>'+
    '<p class="chart-note">'+({day:'按记录开始小时',month:'按日期',year:'按月份'}[scope])+' · '+(time?'专注时长':'支出金额')+(count>7?' · 可横滑':'')+'</p>'+
    '<div class="report-chart '+(count>7?'wide':'')+'" data-latest="'+latest+'" tabindex="0" aria-label="趋势图">'+bars(points,format)+'</div>'+
    breakdowns+logs+'<footer class="page-index">'+dateTitle(date,scope)+'</footer></section>';
}

view.addEventListener('input',event=>{
  if(event.target.id==='quick-text')quickNote.text=event.target.value;
});
view.addEventListener('change',async event=>{
  const target=event.target;
  if(target.name==='direction'&&target.form?.classList.contains('money-form'))syncMoneyGrid('');
  if(target.name==='mode'&&target.form?.id==='task-form')target.form.elements.minutes.closest('label').hidden=target.value==='up';
  if(target.name==='icon'&&target.form?.id==='category-form'){
    categoryArtwork='';
    view.querySelector('#imported-icon').textContent='';
  }
  if(target.id!=='icon-file'||!target.files[0])return;
  const url=URL.createObjectURL(target.files[0]);
  try {
    const img=new Image();
    img.src=url;
    await img.decode();
    if(!target.isConnected)return;
    const size=Math.min(img.naturalWidth,img.naturalHeight);
    const canvas=document.createElement('canvas');
    canvas.width=canvas.height=64;
    const ctx=canvas.getContext('2d');
    ctx.fillStyle='#f9f4e9';
    ctx.fillRect(0,0,64,64);
    ctx.drawImage(img,(img.naturalWidth-size)/2,(img.naturalHeight-size)/2,size,size,0,0,64,64);
    categoryArtwork=canvas.toDataURL('image/jpeg',.84);
    target.form.querySelectorAll('[name=icon]').forEach(input=>input.checked=false);
    view.querySelector('#imported-icon').innerHTML=iconMarkup(categoryArtwork);
  }catch{notify('无法导入这个图标');}
  finally{URL.revokeObjectURL(url);}
});
view.addEventListener('submit',event=>{
  const form=event.target;
  if(!['quick-note','category-form'].includes(form.id))return;
  event.preventDefault();
  event.stopImmediatePropagation();
  if(form.id==='quick-note'){
    if(imagePending){notify('请等图片导入完成');return;}
    const currentDraft=quickNote;
    const text=currentDraft.text.trim();
    if(!text&&!currentDraft.photos.length){notify('请写点文字或添加图片');return;}
    if(commit(next=>{
      const items=next.books.find(b=>b.id===current).entries;
      const entry={id:uid(),day:date,time:Date.now(),text};
      if(currentDraft.photos.length)entry.photos=currentDraft.photos;
      items.push(entry);
    })){quickNote=null;screenBook();notify('已写入本页');}
    return;
  }
  const data=new FormData(form);
  const name=data.get('name').trim();
  const icon=categoryArtwork||data.get('icon')||'◇';
  if(!name){notify('请输入分类名称');return;}
  if(categories(categoryDirection).some(c=>c.name===name&&c.name!==categoryEditing)){notify('已有同名分类');return;}
  if(commit(next=>{
    next.categories ||= {};
    const list=categories(categoryDirection);
    next.categories[categoryDirection]=categoryEditing?list.map(c=>c.name===categoryEditing?{name,icon}:c):[...list,{name,icon}];
    if(categoryEditing&&categoryEditing!==name)for(const book of next.books.filter(b=>b.type==='money')){
      for(const entry of book.entries)if(Boolean(entry.income)===(categoryDirection==='in')&&entry.category===categoryEditing)entry.category=name;
    }
  })){closeSheet();refreshCategoryManager();syncMoneyGrid(name);}
},true);

view.addEventListener('click',event=>{
  const target=event.target.closest('[data-action]');
  if(!target)return;
  const [action,arg]=target.dataset.action.split(':');
  switch(action){
    case 'close-sheet': closeSheet();break;
    case 'image':
      if(!sheetTop())return;
      sheet('photo','手记配图','<img class="full" src="'+esc(device.path(target.dataset.id))+'" alt="手记配图">');
      break;
    case 'manage-categories': categoryManager(target.closest('form').elements.direction.value);break;
    case 'change-category': categoryEditor(Number(arg));break;
    case 'remove-category': {
      const list=categories(categoryDirection);
      if(list.length<2){notify('至少保留一个分类');break;}
      if(window.confirm('删除「'+list[arg].name+'」？已有流水会保留原分类。')&&commit(next=>{
        next.categories ||= {};
        next.categories[categoryDirection]=list.filter((_,i)=>i!==Number(arg));
      })){refreshCategoryManager();syncMoneyGrid('');}
      break;
    }
    case 'quick-photo': attachPhoto('pick','quick');break;
    case 'quick-camera': attachPhoto('camera','quick');break;
    case 'entry-camera': attachPhoto('camera','entry');break;
    case 'quick-remove': quickNote.photos=quickNote.photos.filter(n=>n!==arg);device.remove(arg);drawQuickPhotos();break;
    case 'open-date': dateSheet(arg||'day');break;
    case 'picker-step': {
      const move=Number(arg),scope=datePicker.level;
      datePicker.key=periodMove(datePicker.key,scope==='day'?'month':'year',scope==='year'?move*12:move);
      renderDateSheet();
      break;
    }
    case 'picker-level': datePicker.level=arg;renderDateSheet();break;
    case 'confirm-date':
      if(datePicker.level!==datePicker.scope){
        datePicker.key=arg;
        datePicker.level=datePicker.level==='year'?'month':'day';
        renderDateSheet();
      }else{date=arg;closeSheet();screenBook();}
      break;
    case 'report-step': flipDirection=Number(arg);date=periodMove(date,reportScope[activeBook().type],flipDirection);screenBook('flip');break;
    case 'report-scope': reportScope[activeBook().type]=arg;screenBook('open');break;
    default: return;
  }
  event.stopImmediatePropagation();
},true);
