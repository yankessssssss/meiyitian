const view = document.querySelector('#view');
const notice = document.querySelector('#notice');
const device = window.Device;
const covers = [
  ['#a97644', '◉', '暖阳'], ['#486a82', '✦', '星夜'],
  ['#52755c', '❧', '枝叶'], ['#9b584b', '✿', '花笺'],
  ['#6b6083', '☾', '月影'], ['#48575a', '◈', '格纹']
];
const types = {money:'记账', timer:'时间钟', diary:'日记'};
const initial = {books:[
  {id:'money',name:'记账',type:'money',cover:0,entries:[]},
  {id:'timer',name:'时间钟',type:'timer',cover:1,entries:[]},
  {id:'diary',name:'日记',type:'diary',cover:2,entries:[]}
],timer:null};
let state;
try {
  const raw = device ? device.read() : localStorage.getItem('meiyitian');
  state = raw ? JSON.parse(raw) : initial;
  if (!Array.isArray(state.books)) throw new Error();
} catch {
  view.textContent = '无法读取本机日记。请重新打开应用。';
  throw new Error('Invalid journal');
}

let current = null, date = today(), draft = null, imagePending = false, imageName = null;
let noticeTimeout, opening = false;
const button = (action, label, style='quiet') =>
  '<button type="button" class="'+style+'" data-action="'+action+'">'+label+'</button>';
const esc = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const activeBook = () => state.books.find(b=>b.id===current);
const uid = () => Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);

function day(value) {
  return [value.getFullYear(),String(value.getMonth()+1).padStart(2,'0'),String(value.getDate()).padStart(2,'0')].join('-');
}
function today(){return day(new Date());}
function notify(message){
  notice.textContent=message;
  clearTimeout(noticeTimeout);
  noticeTimeout=setTimeout(()=>notice.textContent='',2800);
}
function commit(change) {
  const next=JSON.parse(JSON.stringify(state));
  change(next);
  try {
    if (device) {
      if (!device.save(JSON.stringify(next))) throw new Error();
    } else localStorage.setItem('meiyitian',JSON.stringify(next));
  } catch {notify('保存失败，请检查手机剩余空间后重试');return false;}
  state=next;
  return true;
}
function bookTile(book, returning) {
  const [color,symbol]=covers[book.cover];
  return '<button class="book cover-'+book.cover+(returning?' returning':'')+'" style="--cover:'+color+'" data-action="open" data-id="'+book.id+'"><span aria-hidden="true">'+symbol+'</span><strong>'+esc(book.name)+'</strong><small>'+book.entries.length+' 条记录</small></button>';
}
function screenShelf(returning) {
  current=null;
  let rows='';
  for(let i=0;i<state.books.length;i+=3){
    rows+='<div class="row">'+state.books.slice(i,i+3).map(b=>bookTile(b,b.id===returning)).join('')+'</div><div class="plank"></div>';
  }
  view.innerHTML='<header class="top"><div><h1>每一天</h1><div class="meta">'+today().replace(/-/g,' · ')+'</div></div>'+button('new-book','＋ 新书','action')+'</header><section class="case" aria-label="我的书架">'+rows+'</section>';
}
function amount(cents){return (cents/100).toFixed(2);}
function elapsed(ms){
  const seconds=Math.max(0,Math.floor(ms/1000));
  return [Math.floor(seconds/3600),Math.floor(seconds/60)%60,seconds%60].map(n=>String(n).padStart(2,'0')).join(':');
}
function stamp(ms){
  return new Date(ms).toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',hour12:false});
}
function photoTag(name, isDraft=false) {
  return '<div><button type="button" class="photo-button" data-action="image" data-id="'+esc(name)+'"><img loading="lazy" decoding="async" src="'+esc(device.path(name))+'" alt="查看配图"></button>'+
    (isDraft?'<button type="button" class="quiet" data-action="remove-photo" data-id="'+esc(name)+'">移除</button>':'')+'</div>';
}
function entryCard(entry, type) {
  let line=esc(entry.text);
  if(type==='money') line=(entry.income?'收入 +':'支出 −')+'¥'+amount(entry.cents)+' · '+line;
  if(type==='timer') line=elapsed(entry.ms)+' · '+line;
  return '<article class="entry"><header><span class="meta">'+stamp(entry.time)+'</span><div>'+button('edit:'+entry.id,'编辑')+' '+button('delete:'+entry.id,'删除','quiet danger')+'</div></header>'+
    (line?'<p>'+line+'</p>':'')+
    (entry.photos?.length && device?'<div class="photos">'+entry.photos.map(n=>photoTag(n)).join('')+'</div>':'')+'</article>';
}
function runningControls(book) {
  const timer=state.timer;
  if(!timer || timer.book!==book.id) return button('start',timer?'已有计时进行中':'开始计时','action');
  return '<div><div class="clock" id="clock"></div><p>'+esc(timer.text)+'</p>'+
    button('stop','结束并保存','action')+' '+button('cancel-timer','取消计时')+'</div>';
}
function screenBook(animation=''){
  const book=activeBook();
  if(!book){screenShelf();return;}
  const entries=book.entries.filter(e=>e.day===date).slice().reverse();
  let summary='';
  if(book.type==='money'){
    const income=entries.reduce((sum,e)=>sum+(e.income?e.cents:0),0);
    const expense=entries.reduce((sum,e)=>sum+(e.income?0:e.cents),0);
    summary='<p>收入 ¥'+amount(income)+'　支出 ¥'+amount(expense)+'<br><strong>结余 ¥'+amount(income-expense)+'</strong></p>';
  } else if(book.type==='timer'){
    summary='<p>当天累计 '+elapsed(entries.reduce((sum,e)=>sum+e.ms,0))+'</p>';
  }
  view.innerHTML='<header>'+button('shelf','‹ 放回书架')+'<h2>'+esc(book.name)+'</h2>'+button('settings','封面')+'</header>'+
    '<section class="paper '+animation+'"><div class="toolbar"><input type="date" aria-label="记录日期" id="date" value="'+date+'" style="width:auto">'+
    (book.type==='timer'?'':button('new-entry','＋ 记录','action'))+'</div>'+summary+
    (book.type==='timer'?runningControls(book):'')+
    (entries.length?entries.map(e=>entryCard(e,book.type)).join(''):'<p class="empty">这一天还没有记录。</p>')+
    '<nav class="pager" aria-label="翻页">'+button('prev','‹ 前一天')+button('today','今天')+button('next','后一天 ›')+'</nav></section>';
  updateClock();
  if(animation) window.scrollTo(0,0);
}
function updateClock(){
  const el=document.querySelector('#clock');
  if(el && state.timer)el.textContent=elapsed(Date.now()-state.timer.start);
}
setInterval(()=>{if(!document.hidden&&state.timer)updateClock();},500);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)updateClock();});
function turn(delta){
  const value=new Date(date+'T12:00:00');
  value.setDate(value.getDate()+delta);
  date=day(value);
  screenBook('flip');
}
function bookForm(book) {
  view.innerHTML='<header>'+button('back','‹ 返回')+'<h2>'+(book?'书本设置':'新增一本书')+'</h2></header><form class="paper open" id="book-form">'+
    '<label>书名<input name="name" required maxlength="30" value="'+esc(book?.name)+'" placeholder="例如 阅读笔记"></label>'+
    (book?'':'<label>记录方式<select name="type"><option value="diary">图文笔记</option><option value="money">收支记账</option><option value="timer">工作计时</option></select></label>')+
    '<fieldset><legend>封面</legend><div class="choices">'+covers.map(([color,symbol,label],index)=>
      '<label class="choice"><input type="radio" name="cover" value="'+index+'" '+((book?.cover??0)===index?'checked':'')+'><span style="--cover:'+color+'">'+symbol+' '+label+'</span></label>').join('')+'</div></fieldset>'+
    '<div class="tools"><button class="action">保存书本</button>'+(book&&!Object.prototype.hasOwnProperty.call(types,book.id)?button('delete-book','删除此书','quiet danger'):'')+'</div></form>';
}
function editEntry(entry) {
  const book=activeBook();
  draft={id:entry?.id,photos:[...(entry?.photos||[])],added:[]};
  const money=book.type==='money', timer=book.type==='timer';
  view.innerHTML='<header>'+button('back','‹ 返回')+'<h2>'+(entry?'编辑记录':timer?'开始计时':'新增记录')+'</h2></header>'+
    '<form class="paper open" id="entry-form"><p class="meta">'+(timer&&!entry?today():date)+'</p>'+
    (money?'<div class="two"><label>收支<select name="direction"><option value="out">支出</option><option value="in" '+(entry?.income?'selected':'')+'>收入</option></select></label><label>金额（元）<input name="amount" type="text" inputmode="decimal" required value="'+(entry?amount(entry.cents):'')+'"></label></div>':'')+
    (money?'<label>分类<input name="category" list="categories" maxlength="24" value="'+esc(entry?.category)+'" placeholder="例如 餐饮、交通或工资"><datalist id="categories"><option value="餐饮"><option value="交通"><option value="购物"><option value="生活"><option value="工资"><option value="兼职"></datalist></label>':'')+
    '<label>'+(money?'用途或来源':timer?'工作内容':'写下此刻')+'<textarea name="text" maxlength="12000">'+esc(entry?.text)+'</textarea></label>'+
    (!money&&!timer&&device?button('photo','＋ 添加图片')+'<div class="photos" id="draft-photos"></div>':'')+
    '<button class="action">'+(timer&&!entry?'开始':'保存记录')+'</button></form>';
  refreshPhotos();
}
function refreshPhotos(){
  const el=document.querySelector('#draft-photos');
  if(el)el.innerHTML=draft.photos.map(n=>photoTag(n,true)).join('');
}
function photoReady(name){
  imagePending=false;
  if(!draft){device.remove(name);return;}
  draft.photos.push(name);
  draft.added.push(name);
  refreshPhotos();
}
function photoCancelled(){imagePending=false;}
function photoFailed(){imagePending=false;notify('无法导入这张图片');}
function clearDraft(keep=[]){
  if(draft && device)draft.added.filter(n=>!keep.includes(n)).forEach(n=>device.remove(n));
  draft=null;
}
function goBack(){
  if(imageName){document.querySelector('#photo-view')?.remove();imageName=null;return;}
  if(imagePending){notify("请等图片导入完成");return;}
  if(draft){clearDraft();screenBook();return;}
  if(document.querySelector('#book-form')){current?screenBook():screenShelf();return;}
  if(current)screenShelf(current);
}
function saveTimer(){
  const t=state.timer;
  const end=Math.max(t.start,Date.now());
  const entries=[];
  let start=t.start;
  do {
    const midnight=new Date(start);
    midnight.setHours(24,0,0,0);
    const stop=Math.min(end,midnight.getTime());
    entries.push({id:uid(),day:day(new Date(start)),time:start,text:t.text,ms:stop-start});
    start=stop;
  } while(start<end);
  if(commit(next=>{
    next.books.find(b=>b.id===t.book).entries.push(...entries);
    next.timer=null;
  })){date=entries[entries.length-1].day;screenBook('flip');}
}
view.addEventListener('change',event=>{
  if(event.target.id==='date' && event.target.value){date=event.target.value;screenBook('flip');}
});
view.addEventListener('submit',event=>{
  event.preventDefault();
  const data=new FormData(event.target);
  const book=activeBook();
  if(event.target.id==='book-form'){
    const name=data.get('name').trim();
    if(!name){notify('请输入书名');return;}
    const cover=Number(data.get('cover'));
    const id=book?.id||uid();
    if(commit(next=>{
      if(book)Object.assign(next.books.find(b=>b.id===id),{name,cover});
      else next.books.push({id,name,cover,type:data.get('type'),entries:[]});
    })){current=id;date=book?date:today();screenBook('open');}
    return;
  }
  if(imagePending){notify('图片正在导入');return;}
  const message=data.get('text').trim();
  const old=book.entries.find(e=>e.id===draft.id);
  const entry={id:old?.id||uid(),day:date,time:old?.time||Date.now(),text:message};
  if(book.type==='timer'){
    if(!message){notify('请输入工作内容');return;}
    if(!old){
      if(state.timer){notify('请先结束正在运行的计时');return;}
      if(commit(next=>next.timer={book:book.id,text:message,start:Date.now()})){
        clearDraft();date=today();screenBook();
      }
      return;
    }
    entry.ms=old.ms;
  }else if(book.type==='money'){
    const raw=data.get('amount').trim().replace(',','.');
    if(!/^\d{1,9}(\.\d{1,2})?$/.test(raw) || Number(raw)<=0){notify('请输入有效金额，最多两位小数');return;}
    entry.cents=Math.round(Number(raw)*100);
    entry.income=data.get('direction')==='in';
    entry.category=(data.get('category')||'').trim();
  }else{
    if(!message&&!draft.photos.length){notify('请输入文字或添加图片');return;}
    if(draft.photos.length)entry.photos=draft.photos;
  }
  if(commit(next=>{
    const list=next.books.find(b=>b.id===book.id).entries;
    if(old)list[list.findIndex(e=>e.id===old.id)]=entry;
    else list.push(entry);
  })){
    if(device)(old?.photos||[]).filter(n=>!draft.photos.includes(n)).forEach(n=>device.remove(n));
    clearDraft(entry.photos||[]);
    screenBook();
    notify('已保存');
  }
});
view.addEventListener('click',event=>{
  const target=event.target.closest('[data-action]');
  if(!target)return;
  const [action,id]=target.dataset.action.split(':');
  const book=activeBook();
  switch(action){
    case 'open':
      if(opening)return;
      opening=true;
      target.classList.add('leaving');
      setTimeout(()=>{opening=false;current=target.dataset.id;date=today();screenBook('open');},180);
      break;
    case 'back':case 'shelf':goBack();break;
    case 'new-book':bookForm();break;
    case 'settings':bookForm(book);break;
    case 'prev':turn(-1);break;
    case 'next':turn(1);break;
    case 'today':date=today();screenBook('flip');break;
    case 'new-entry':editEntry();break;
    case 'edit':editEntry(book.entries.find(e=>e.id===id));break;
    case 'start':state.timer?notify('请先结束正在运行的计时'):editEntry();break;
    case 'stop':saveTimer();break;
    case 'cancel-timer':
      if(window.confirm('放弃本次计时？')&&commit(next=>next.timer=null))screenBook();
      break;
    case 'photo':
      if(!imagePending){imagePending=true;device.pick();}
      break;
    case 'remove-photo':
      draft.photos=draft.photos.filter(n=>n!==target.dataset.id);refreshPhotos();break;
    case 'image':
      imageName=target.dataset.id;
      view.insertAdjacentHTML('beforeend','<div id="photo-view">'+button('back','关闭')+'<img class="full" alt="日记配图" src="'+esc(device.path(imageName))+'"></div>');
      break;
    case 'delete':
      if(!window.confirm('删除这条记录？'))return;
      if(commit(next=>{
        const b=next.books.find(b=>b.id===book.id);
        b.entries=b.entries.filter(e=>e.id!==id);
      })){
        if(device)(book.entries.find(e=>e.id===id).photos||[]).forEach(n=>device.remove(n));
        screenBook();
      }
      break;
    case 'delete-book':
      if(state.timer?.book===book.id){notify('请先结束这本书的计时');return;}
      if(window.confirm('删除这本书及其中的全部记录？')&&commit(next=>next.books=next.books.filter(b=>b.id!==book.id))){
        if(device)book.entries.flatMap(e=>e.photos||[]).forEach(n=>device.remove(n));
        screenShelf();
      }
      break;
  }
});
screenShelf();




